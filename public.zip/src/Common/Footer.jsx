import React, { useEffect, useState } from "react";
import home from "../Photos/Home.png";
import clipboard from "../Photos/clipboard-list.png";
import comments from "../Photos/comments.png";
import user_circle from "../Photos/user-circle.png";
import logo from "../Photos/logo.png";
import { NavLink, useNavigate } from "react-router-dom";
import secureLocalStorage from "react-secure-storage";
import { showToast } from "../Components/Services/ToastService";

const Footer = () => {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [profile, setProfile] = useState(secureLocalStorage.getItem("profile"));
  const showListing = () => {
    if (show === true) {
      setShow(false);
    } else {
      setShow(true);
    }
  };
  const [name, setName] = useState("");

  const logout = () => {
    secureLocalStorage.clear();
    showToast("success", "Success Message", "Log Out Successfully");
    navigate("/login");
  };

  useEffect(() => {
    setName(secureLocalStorage.getItem("name"));
  }, []);

  return (
    <>
      <div className="container padding_none">
        <div className="footer_main">
          <div className="absolute_profile_footer">
            <NavLink to="/">
              <div className="cirlce_footer_logo">
                <img src={logo} alt="lgog" />
              </div>
            </NavLink>
          </div>
          <div className="footer_bg">
            <div className="footer_listing">
              <ul>
                <li>
                  <NavLink to="/">
                    <img src={home} alt="home_icon" />
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/">
                    <img src={clipboard} alt="clipboard_icon" />
                  </NavLink>
                </li>
                <li></li>
                <li>
                  <NavLink to="/">
                    <img src={comments} alt="comments_icon" />
                  </NavLink>
                </li>
                {name ? (
                  <li onClick={showListing}>
                    <img
                      src={profile === null ? user_circle : profile}
                      alt="user_circle_icon"
                      className="profile_img"
                    />
                  </li>
                ) : (
                  <li onClick={showListing}>
                    <img src={user_circle} alt="user_circle_icon" />
                  </li>
                )}
              </ul>
            </div>
            {name ? (
              <>
                {show ? (
                  <div
                    className="dropdown_listing_login"
                    onClick={() => setShow(false)}
                  >
                    <ul>
                      <li>
                        <NavLink to="/profile">
                          <i className="fa fa-user"></i> Manage Profile
                        </NavLink>
                      </li>
                      <li>
                        <NavLink to="/profile">
                          <i className="fa fa-user"></i> Ongoing Projects
                        </NavLink>
                      </li>
                      <li>
                        <NavLink to="/profile">
                          <i className="fa fa-user"></i> Completed Projects
                        </NavLink>
                      </li>
                      <li>
                        <NavLink to="/profile">
                          <i className="fa fa-user"></i> Declined Projects
                        </NavLink>
                      </li>
                      <li>
                        <NavLink to="/profile">
                          <i className="fa fa-user"></i> Preferred Locations
                        </NavLink>
                      </li>
                      <li>
                        <NavLink to="/profile">
                          <i className="fa fa-user"></i> Notifications
                        </NavLink>
                      </li>
                      <li>
                        <div onClick={logout} className="logout_text pointer">
                          <i className="fa fa-lock"></i> Log Out
                        </div>
                      </li>
                    </ul>
                  </div>
                ) : (
                  ""
                )}
              </>
            ) : (
              <>
                {show ? (
                  <div
                    className="dropdown_listing"
                    onClick={() => setShow(false)}
                  >
                    <ul>
                      <li>
                        <NavLink to="/login">
                          <i className="fa fa-lock"></i> Login
                        </NavLink>
                      </li>
                      <li>
                        <NavLink to="/">
                          <i className="fa fa-user-plus"></i> Register
                        </NavLink>
                      </li>
                    </ul>
                  </div>
                ) : (
                  ""
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Footer;
