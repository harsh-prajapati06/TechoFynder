import React from "react";
import header from "../Photos/Header.png";

const Header = () => {
  return (
    <>
      <section className="header_img">
        <img src={header} />
      </section>
    </>
  );
};

export default Header;
