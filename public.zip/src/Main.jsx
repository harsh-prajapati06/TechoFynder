import React, { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import Footer from "./Common/Footer";

const Main = () => {
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);

  const handleResize = () => {
    setScreenWidth(window.innerWidth);
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const visibility = screenWidth < 600 ? "show" : "hide";

  return (
    <>
      <Outlet />
      <Footer />
    </>
  );
};

export default Main;
