import React, { useEffect, useRef, useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Index from "./Components/Index";
import Profile from "./Components/Profile";
import "./Css/Style.css";
import Login from "./Components/Auth/Login";
import Layout from "./Layout";
import Main from "./Main";
import {
  ToastComponent,
  setToastRef,
} from "./Components/Services/ToastService";

const App = () => {
  const pathName = window.location.pathname;
  if (pathName === "/profile") {
    document.body.style.background = "#2F2F2F";
  } else {
    document.body.style.background = "white";
  }
  const toastRef = useRef(null);
  setToastRef(toastRef);

  return (
    <>
      <ToastComponent />
      <Router>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/login" element={<Login />} />
          </Route>
        </Routes>

        <Routes>
          <Route element={<Main />}>
            <Route path="/" element={<Index />} />
            <Route path="/profile" element={<Profile />} />
          </Route>
        </Routes>
      </Router>
    </>
  );
};

export default App;
