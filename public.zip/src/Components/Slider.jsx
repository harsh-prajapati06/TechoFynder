import React, { useState } from "react";

const Slider = ({ images, captions }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  const curruntImage = (index) => {
    setCurrentImageIndex(index);
  };
  setTimeout(() => {
    currentImageIndex === images.length - 1
      ? setCurrentImageIndex(0)
      : setCurrentImageIndex(currentImageIndex + 1);
  }, 5000);

  return (
    <>
      <div className="carousel">
        <div className="flex_centered">
          {/* <button className="prev slider_btn" onClick={prevImage}>
            <i className="fa fa-arrow-left"></i>
          </button> */}
          <img
            className="slider_img"
            src={images[currentImageIndex]}
            alt="carousel"
          />
          {/* <button className="next slider_btn" onClick={nextImage}>
            <i className="fa fa-arrow-right"></i>
          </button> */}
        </div>
        <div className="caption">
          <div>
            <p>{captions[currentImageIndex]}</p>
            <div className="nav_buttons">
              {images.map((image, index) => {
                return (
                  <>
                    <div
                      key={index}
                      className={
                        currentImageIndex === index ? "div_active" : ""
                      }
                      onClick={() => curruntImage(index)}
                    ></div>
                  </>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Slider;
