import { createRef } from "react";
import { Toast } from "primereact/toast";
import "primereact/resources/primereact.css";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primeflex/primeflex.css";

// Initialize a ref for the Toast component
let toastRef = createRef();

export const showToast = (severity, summary, detail) => {
  if (toastRef.current) {
    toastRef.current.show({ severity, summary, detail });
  }
};

export const setToastRef = (ref) => {
  toastRef = ref;
};

export const ToastComponent = () => {
  return <Toast ref={toastRef} />;
};
