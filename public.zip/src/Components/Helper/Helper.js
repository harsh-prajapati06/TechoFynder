import axios from "axios";
export const BASE_URL = "https://partner.techofynder.com/api/";
export const clientId =
  "570257748981-qs43n38jgmaf2di3guluftc9v4b573vq.apps.googleusercontent.com";

// export const Timeout = (time) => {
//   let controller = new AbortController();
//   setTimeout(() => controller.abort(), time * 1000);
//   return controller;
// };

export const myAxios = axios.create({
  baseURL: BASE_URL,
});
