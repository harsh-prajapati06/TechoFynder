import React, { useEffect, useState } from "react";
import secureLocalStorage from "react-secure-storage";

const Profile = () => {
  const [name, setName] = useState("");

  useEffect(() => {
    setName(secureLocalStorage.getItem("name"));
  }, []);
  return (
    <>
      <div className="container">
        <div className="flex_justify">
          <div className="pointer back_arrow">
            <i className="fa fa-angle-left"></i>
          </div>

          <p className="capital_profile_title">Hello, {name ? name : ""}</p>

          <div className="profile_circle">
            {name ? (
              <img
                src={secureLocalStorage.getItem("profile")}
                alt="profile_pic"
              />
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Profile;
