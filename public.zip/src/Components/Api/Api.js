import { myAxios } from "../Helper/Helper";

export const sendLogin = (data) => {
  return myAxios.post("login", data).then((response) => response.data);
};

export const signUp = (data) => {
  return myAxios.post("signUp", data).then((response) => response.data);
};
