import React, { useEffect } from "react";
import Header from "../Common/Header";
import banner_img_1 from "../Photos/slide_1.png";
import quoute from "../Photos/quoute.png";
import profile from "../Photos/profile.png";
import Slider from "./Slider";

const Index = () => {
  const images = [banner_img_1, banner_img_1, banner_img_1];

  const captions = [
    "TechoFynder brings a platform for talented engineers",
    "TechoFynder brings a platform for talented engineers",
    "TechoFynder brings a platform for talented engineers",
  ];
  
  return (
    <>
      <Header />

      <Slider images={images} captions={captions} />
      {/* <img src={banner_img_1} alt="banner_img" width="100%" /> */}

      <div className="container">
        <div className="row margin_top_section">
          <div className="col-4">
            <div className="card_box">
              <div className="card_box_header">
                <p className="card_top_text">245</p>
              </div>
              <div className="card_box_body">
                <p className="card_body_text">
                  leading corporations who trust us
                </p>
              </div>
            </div>
          </div>
          <div className="col-4">
            <div className="card_box">
              <div className="card_box_header">
                <p className="card_top_text">245</p>
              </div>
              <div className="card_box_body">
                <p className="card_body_text">
                  leading corporations who trust us
                </p>
              </div>
            </div>
          </div>
          <div className="col-4">
            <div className="card_box">
              <div className="card_box_header">
                <p className="card_top_text">245</p>
              </div>
              <div className="card_box_body">
                <p className="card_body_text">
                  leading corporations who trust us
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="row margin_top_section">
          <div className="col-md-12">
            <h2 className="page_title">Know more about us</h2>

            <p className="page_description">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text.
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>

            <p className="page_description mt-3">
              Lorem Ipsum has been the industry's standard dummy text. Lorem
              Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text.
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text.
            </p>
          </div>
        </div>

        <div className="row margin_top_section">
          <div className="col-md-12">
            <h2 className="page_title">What our Engineers Say</h2>

            <div className="engineers_card">
              <div className="absolute_div">
                <img src={profile} alt="profile" />
                <div className="profile_flex">
                  <p className="profile_title">Mark Jackson</p>
                  <p className="titme_description">Engineer</p>
                </div>
              </div>
              <div className="inner_div_description">
                <div className="flex_items_center">
                  <div className="img_qoute">
                    <img src={quoute} />
                  </div>
                  <p className="description_of_card">
                    I would like to thank your company personnel at the customer
                    services division for their excellent support. My
                    Relationship Manager, Esther Monicka, took care of all
                    jiffy.
                  </p>
                  <div className="end_flex">
                    <div className="img_qoute">
                      <img src={quoute} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Index;
