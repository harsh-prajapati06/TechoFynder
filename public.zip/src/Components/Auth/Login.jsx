import React, { useState } from "react";
import login from "../../Photos/login.png";
import slide_1 from "../../Photos/slide_1.png";
import SignUp from "./SignUp";
import Slider from "../Slider";
import { GoogleOAuthProvider } from "@react-oauth/google";
import Google from "./Google";
import { clientId } from "../Helper/Helper";
import * as Yup from "yup";
import { useFormik } from "formik";
import { sendLogin } from "../Api/Api";
import { showToast } from "../Services/ToastService";

const LoginValid = Yup.object().shape({
  mobile: Yup.string()
    .matches(/^[0-9]{10}$/, "Invalid mobile number")
    .required("Mobile can not be left blank"),
});

const Login = () => {
  const [signUpDiv, setSignUpDiv] = useState(false);

  const images = [login, slide_1, login];

  const captions = [
    "TechoFynder brings a platform for talented engineers",
    "TechoFynder brings a platform for talented engineers",
    "TechoFynder brings a platform for talented engineers",
  ];

  const [otp, setOtp] = useState(false);

  const loginFormik = useFormik({
    initialValues: {
      mobile: "",
    },
    validationSchema: LoginValid,
    onSubmit: (values, { resetForm }) => {
      sendLogin(values)
        .then((resp) => {
          if (resp.success === true) {
            resetForm();
            setOtp(true);
          } else {
            showToast("error", "Error Message", resp.message);
          }
        })
        .catch((error) => {});
    },
  });

  return (
    <>
      <Slider images={images} captions={captions} />
      <div className="container marginTopSection">
        <div className="row login_margin">
          <div className="col-md-12 mobile_no_div text-center">
            {signUpDiv ? (
              <>
                <h3 className="signup_title">
                  Enter the details of your new account
                </h3>
                <p className="login_description">
                  Already have an account?{" "}
                  <b className="pointer" onClick={() => setSignUpDiv(false)}>
                    Login
                  </b>
                </p>
              </>
            ) : (
              <>
                <h3 className="login_title">Sign in to your account</h3>
                <p className="login_description">
                  Don’t have an account?{" "}
                  <b className="pointer" onClick={() => setSignUpDiv(true)}>
                    Sign Up
                  </b>
                </p>
              </>
            )}
          </div>

          {signUpDiv ? (
            <SignUp />
          ) : (
            <>
              <form onSubmit={loginFormik.handleSubmit}>
                <div className="col-md-12 text-center marginTopTwenty">
                  <input
                    type="tel"
                    className="input-control"
                    maxLength={10}
                    id="mobile"
                    name="mobile"
                    placeholder="Phone No."
                    value={loginFormik.values.mobile}
                    onChange={(e) => {
                      loginFormik.handleChange(e);
                    }}
                    onBlur={loginFormik.handleBlur}
                  />

                  {loginFormik.touched.mobile && loginFormik.errors.mobile ? (
                    <p className="error_alert">{loginFormik.errors.mobile}</p>
                  ) : null}

                  <div className="flex_input_text">
                    <input
                      type="checkbox"
                      id="whatsapp_update"
                      name="whatsapp_update"
                    />
                    <p>
                      <span>Get Update On</span>{" "}
                      <i className="fa fa-whatsapp"></i> <span>Whatsapp</span>
                    </p>
                  </div>
                </div>

                <div className="col-md-12 marginTopTwenty text-center">
                  <button type="submit" className="login_btn">
                    Send Otp
                  </button>
                </div>
              </form>
            </>
          )}

          <div className="col-md-12 marginTopTwenty text-center">
            <p className="desh_title">or connect with</p>
          </div>

          <GoogleOAuthProvider clientId={clientId}>
            <Google />
          </GoogleOAuthProvider>
        </div>
      </div>
    </>
  );
};

export default Login;
