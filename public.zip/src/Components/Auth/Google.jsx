import React from "react";
import google from "../../Photos/google.png";
import { GoogleLogin } from "@react-oauth/google";
import { jwtDecode } from "jwt-decode";
import { showToast } from "../Services/ToastService";
import secureLocalStorage from "react-secure-storage";
import { useNavigate } from "react-router-dom";
import { BASE_URL, myAxios } from "../Helper/Helper";

const Google = () => {
  const navigate = useNavigate();
  const responseGoogle = async (response) => {
    if (response.error) {
      showToast("error", "Error Message", "Login Failed");
    } else {
      const data = jwtDecode(response.credential);

      const requestedData = {
        email: data.email,
        name: data.name,
        auth_provider: "Google",
      };

      myAxios({
        method: "POST",
        url: BASE_URL + "googleLogin",
        data: requestedData,
      })
        .then((response) => {
          if (response.data.status === true) {
            // alert(JSON.stringify(response));
            secureLocalStorage.setItem("user_id", response.data.data.id);
            secureLocalStorage.setItem("mobile", response.data.data.mobile);
            secureLocalStorage.setItem("name", response.data.data.name);
            secureLocalStorage.setItem("userName", response.data.data.userName);
            secureLocalStorage.setItem("email", response.data.data.email);
            secureLocalStorage.setItem("profile", response.data.data.photo);
            secureLocalStorage.setItem("role_id", response.data.data.role_id);
            secureLocalStorage.setItem("address", response.data.data.address);
            showToast("success", "Success Message", response.data.message);
            navigate("/");
          } else {
            showToast("error", "Error Message", response.data.message);
          }
        })
        .catch((error) => {
          showToast("error", "Error Message", error.response.data.message);
        });
    }
  };

  return (
    <>
      <div className="col-md-12 marginTopTwenty flex_centered">
        <GoogleLogin
          clientId="570257748981-qs43n38jgmaf2di3guluftc9v4b573vq.apps.googleusercontent.com"
          onSuccess={responseGoogle}
          onFailure={responseGoogle}
          cookiePolicy={"single_host_origin"}
        />
        {/* <button className="google_btn">
          <img src={google} alt="google_icon" />
        </button> */}
      </div>
    </>
  );
};

export default Google;
