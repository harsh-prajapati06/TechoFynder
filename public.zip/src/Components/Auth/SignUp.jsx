import { useFormik } from "formik";
import React, { useState } from "react";
import * as Yup from "yup";
import { signUp } from "../Api/Api";
import { showToast } from "../Services/ToastService";

const signUpValid = Yup.object().shape({
  name: Yup.string().required("Name can not be left blank"),
  pincode: Yup.string()
    .length(6, "Pincode must be exactly 6 characters long")
    .required("Pincode can not be left blank"),
  city_state: Yup.string().required("City And State can not be left blank"),
  aadhaar: Yup.string()
    .length(12, "Aadhaar No. must be exactly 12 characters long")
    .required("Aadhaar No. can not be left blank"),

  email: Yup.string()
    .email("Invalid email address")
    .required("Email can not be left blank"),

  mobile: Yup.string()
    .matches(/^[0-9]{10}$/, "Invalid mobile number")
    .required("Mobile can not be left blank"),
});

const SignUp = () => {
  const [signUpDiv, setSignUpDiv] = useState(false);
  const [password, setPassword] = useState(false);
  const [cPassword, setCPassword] = useState(false);

  const [isChecked, setIsChecked] = useState(false);
  const [otp, setOtp] = useState("");

  const signupFormik = useFormik({
    initialValues: {
      name: "",
      mobile: "",
      email: "",
      pincode: "",
      city_state: "",
      aadhaar: "",
    },
    validationSchema: signUpValid,
    onSubmit: (values, { resetForm }) => {
      signUp(values)
        .then((resp) => {
          if (resp.status === true) {
            resetForm();
            setOtp(resp.otp);
            showToast("success", "Success Message", resp.message);
          } else {
            showToast("error", "Error Message", resp.message);
          }
        })
        .catch((error) => {});
    },
  });

  return (
    <>
      <form onSubmit={signupFormik.handleSubmit}>
        <div className="row">
          <div className="col-md-12 text-center marginTopTwenty">
            <input
              type="text"
              className="input-control"
              id="name"
              name="name"
              placeholder="Full Name"
              value={signupFormik.values.name}
              onChange={(e) => {
                signupFormik.handleChange(e);
              }}
              onBlur={signupFormik.handleBlur}
            />
            {signupFormik.touched.name && signupFormik.errors.name ? (
              <p className="error_alert">{signupFormik.errors.name}</p>
            ) : null}
          </div>
          <div className="col-6 margin_top_2">
            <input
              type="text"
              className="input-control"
              id="mobile"
              name="mobile"
              placeholder="Phone No."
              value={signupFormik.values.mobile}
              onChange={(e) => {
                signupFormik.handleChange(e);
              }}
              onBlur={signupFormik.handleBlur}
            />
            {signupFormik.touched.mobile && signupFormik.errors.mobile ? (
              <p className="error_alert">{signupFormik.errors.mobile}</p>
            ) : null}
          </div>
          <div className="col-6 margin_top_2">
            <input
              type="text"
              className="input-control"
              id="email"
              name="email"
              placeholder="Email Id"
              value={signupFormik.values.email}
              onChange={(e) => {
                signupFormik.handleChange(e);
              }}
              onBlur={signupFormik.handleBlur}
            />
            {signupFormik.touched.email && signupFormik.errors.email ? (
              <p className="error_alert">{signupFormik.errors.email}</p>
            ) : null}
          </div>
          {/* <div className="col-6 margin_top_2">
            <div className="form_group">
              <input
                type={password ? "text" : "password"}
                className="input-control"
                id="password"
                name="password"
                placeholder="Password"
              />

              <div className="password_show">
                {password ? (
                  <i
                    className="fa fa-eye"
                    onClick={() => setPassword(false)}
                  ></i>
                ) : (
                  <i
                    className="fa fa-eye-slash"
                    onClick={() => setPassword(true)}
                  ></i>
                )}
              </div>
            </div>
          </div>

          <div className="col-6 margin_top_2">
            <div className="form_group">
              <input
                type={cPassword ? "text" : "password"}
                className="input-control"
                id="confirm_password"
                name="confirm_password"
                placeholder="Confirm it"
              />

              <div className="password_show">
                {cPassword ? (
                  <i
                    className="fa fa-eye"
                    onClick={() => setCPassword(false)}
                  ></i>
                ) : (
                  <i
                    className="fa fa-eye-slash"
                    onClick={() => setCPassword(true)}
                  ></i>
                )}
              </div>
            </div>
          </div> */}

          <div className="col-6 margin_top_2">
            <input
              type="text"
              className="input-control"
              id="pincode"
              name="pincode"
              placeholder="Pin Code"
              value={signupFormik.values.pincode}
              onChange={(e) => {
                signupFormik.handleChange(e);
              }}
              onBlur={signupFormik.handleBlur}
            />
            {signupFormik.touched.pincode && signupFormik.errors.pincode ? (
              <p className="error_alert">{signupFormik.errors.pincode}</p>
            ) : null}
          </div>

          <div className="col-6 margin_top_2">
            <input
              type="text"
              className="input-control"
              id="city_state"
              name="city_state"
              placeholder="City, State"
              value={signupFormik.values.city_state}
              onChange={(e) => {
                signupFormik.handleChange(e);
              }}
              onBlur={signupFormik.handleBlur}
            />
            {signupFormik.touched.city_state &&
            signupFormik.errors.city_state ? (
              <p className="error_alert">{signupFormik.errors.city_state}</p>
            ) : null}
          </div>

          <div className="col-12 margin_top_2">
            <input
              type="text"
              className="input-control"
              id="aadhaar"
              name="aadhaar"
              maxLength={12}
              placeholder="Aadhaar No."
              value={signupFormik.values.aadhaar}
              onChange={(e) => {
                signupFormik.handleChange(e);
              }}
              onBlur={signupFormik.handleBlur}
            />
            {signupFormik.touched.aadhaar && signupFormik.errors.aadhaar ? (
              <p className="error_alert">{signupFormik.errors.aadhaar}</p>
            ) : null}
          </div>

          <div className="col-12">
            <div className="flex_input_text">
              <input
                type="checkbox"
                id="whatsapp_update"
                name="whatsapp_update"
                checked={isChecked}
                onClick={() => setIsChecked(!isChecked)}
              />
              <p>I accept all terms & conditions</p>
            </div>
          </div>

          <div className="col-md-12 marginTopTwenty text-center">
            <button type="submit" className="login_btn">
              Send OTP
            </button>
          </div>
        </div>
      </form>
    </>
  );
};

export default SignUp;
